public class questao7 {

   
    public static class MensagemDeBoasVindas {
    

        public static void boaVindas() {
            System.out.println("Bem-vindo ao Java!");
        }
    
        public static void main(String[] args) {
          
            boaVindas();
        }
    }
}
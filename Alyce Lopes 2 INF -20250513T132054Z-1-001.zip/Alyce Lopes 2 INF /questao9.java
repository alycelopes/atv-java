public class questao9 {

   
    public static class Aluno {
        String nome;
        int idade;
    }

    public static void main(String[] args) {
       
        Aluno aluno1 = new Aluno();
    
        
        aluno1.nome = "Maria";
        aluno1.idade = 20;
    
    
        System.out.println("Nome do aluno: " + aluno1.nome);
        System.out.println("Idade do aluno: " + aluno1.idade);
    }
}
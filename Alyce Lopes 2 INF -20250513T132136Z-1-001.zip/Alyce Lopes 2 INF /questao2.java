public class questao2 {

   
    public static class SomaValores {
        public static void main(String[] args) {
          
            int numero1 = 10;
            int numero2 = 20;
    
       
            int soma = numero1 + numero2;
    
          
            System.out.println("A soma de " + numero1 + " e " + numero2 + " é: " + soma);
        }
    }
}
public class questao5 {

   
    public static class NumerosDe1a10 {

        public static void main(String[] args) {
           
            for (int i = 1; i <= 10; i++) {
                System.out.println(i);
            }
        }
    }
}